package MyShapes;

public class Square extends Rectangle{

}
