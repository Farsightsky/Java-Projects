package MyShapes;

public class RightTriangle extends Rectangle{
	public float height = 2;
}
