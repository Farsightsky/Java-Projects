package MyPersons;

public class graduateStudent implements Student, Faculty{												//this class will inherit the methods of the super-interfaces
}
